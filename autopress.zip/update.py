import os
import sys
import subprocess
from io import BytesIO
def install_and_import(module):
    try:
        __import__(module)
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", module])
        __import__(module)
install_and_import("requests")
install_and_import("zipfile")
import zipfile
import requests
zip_url = "https://alexidians.github.io/AutoPress/downloads/autopress.zip"
def update_autopress():
    response = requests.get(zip_url)
    
    if response.status_code == 200:
        with zipfile.ZipFile(BytesIO(response.content)) as zip_ref:
            for file_name in zip_ref.namelist():
                if file_name != 'update.py':
                    zip_ref.extract(file_name, path='.')
    else:
        print(f"Failed to update AutoPress from {zip_url}. Status code: {response.status_code}")
if __name__ == "__main__":
    update_autopress()
