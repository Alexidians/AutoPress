import subprocess
import sys
import json
import os

def install_and_import(module):
    try:
        __import__(module)
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", module])
        __import__(module)

install_and_import("pyautogui")
install_and_import("easygui")
install_and_import("keyboard")

import pyautogui
import easygui
import keyboard
import threading
import time

SETTINGS_DIR = 'settings'
AUTOCLICK_SETTINGS_FILE = os.path.join(SETTINGS_DIR, 'autoclick.json')
AUTOKEY_SETTINGS_FILE = os.path.join(SETTINGS_DIR, 'autokey.json')

class AutoClick:
    def __init__(self):
        self.settings_file = AUTOCLICK_SETTINGS_FILE
        self.settings = self.load_settings()
        self.interval = self.settings.get('interval', 0.1)
        self.button_type = self.settings.get('button_type', 'left')
        self.click_type = self.settings.get('click_type', 'single')
        self.toggle_key = self.settings.get('toggle_key', 'f6')
        self.repeat_mode = self.settings.get('repeat_mode', 'until_stopped')
        self.repeat_times = self.settings.get('repeat_times', 1)
        self.running = False

        self.old_toggle_key = self.toggle_key

        self.setup_gui()

    def load_settings(self):
        if not os.path.exists(SETTINGS_DIR):
            os.makedirs(SETTINGS_DIR)
        if os.path.exists(self.settings_file):
            with open(self.settings_file, 'r') as f:
                return json.load(f)
        else:
            return {}

    def save_settings(self):
        with open(self.settings_file, 'w') as f:
            json.dump({
                'interval': self.interval,
                'button_type': self.button_type,
                'click_type': self.click_type,
                'toggle_key': self.toggle_key,
                'repeat_mode': self.repeat_mode,
                'repeat_times': self.repeat_times
            }, f)

    def setup_gui(self):
        msg = "AutoClick Settings"
        title = "AutoClick"
        fieldNames = ["Millennium", "Century", "Year", "Month", "Week", "Day", "Hour", "Minute", "Second", "Millisecond",
                      "Button Type (left/right)", "Click Type (single/double)", "Toggle Key", "Repeat Mode (until_stopped/times)", "Repeat Times"]
        defaults = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    self.button_type, self.click_type, self.toggle_key, self.repeat_mode, self.repeat_times]
        while True:
            fieldValues = easygui.multenterbox(msg, title, fieldNames, defaults)
            if fieldValues:
                try:
                    time_params = {
                        'millisecond': int(fieldValues[9]),
                        'second': int(fieldValues[8]),
                        'minute': int(fieldValues[7]),
                        'hour': int(fieldValues[6]),
                        'day': int(fieldValues[5]),
                        'week': int(fieldValues[4]),
                        'month': int(fieldValues[3]),
                        'year': int(fieldValues[2]),
                        'century': int(fieldValues[1]),
                        'millennium': int(fieldValues[0])
                    }
                    self.interval = sum(value * multiplier for key, multiplier in {
                        'millennium': 1000 * 60 * 60 * 24 * 365 * 1000,
                        'century': 1000 * 60 * 60 * 24 * 365 * 100,
                        'year': 1000 * 60 * 60 * 24 * 365,
                        'month': 1000 * 60 * 60 * 24 * 30,
                        'week': 1000 * 60 * 60 * 24 * 7,
                        'day': 1000 * 60 * 60 * 24,
                        'hour': 1000 * 60 * 60,
                        'minute': 1000 * 60,
                        'second': 1000,
                        'millisecond': 1
                    }.items() if key in time_params for value in [time_params[key]]) / 1000
                except ValueError:
                    continue

                if fieldValues[10].lower() in ['left', 'right']:
                    self.button_type = fieldValues[10].lower()
                else:
                    continue

                if fieldValues[11].lower() in ['single', 'double']:
                    self.click_type = fieldValues[11].lower()
                else:
                    continue

                self.toggle_key = fieldValues[12].lower()

                if fieldValues[13].lower() in ['until_stopped', 'times']:
                    self.repeat_mode = fieldValues[13].lower()
                else:
                    continue

                try:
                    self.repeat_times = int(fieldValues[14])
                except ValueError:
                    continue

                self.update_hotkey()
                self.save_settings()
                break
            else:
                sys.exit()

        self.show_controls()

    def update_hotkey(self):
        if self.old_toggle_key != self.toggle_key:
            keyboard.remove_hotkey(self.old_toggle_key)
            self.old_toggle_key = self.toggle_key
        keyboard.add_hotkey(self.toggle_key, self.toggle_autoclicker)

    def show_controls(self):
        msg = "AutoClick is running.\n\n" \
              "Press the toggle key to start/stop clicking.\n" \
              "Press the Settings button to update settings.\n" \
              "Press the exit button to close the application."
        title = "AutoClick Running"
        choices = ["Settings", "Exit"]
        choice = easygui.buttonbox(msg, title, choices)

        if choice == "Settings":
            self.setup_gui()
        elif choice == "Exit":
            sys.exit()

    def click_mouse(self):
        count = 0
        while self.running:
            if self.repeat_mode == 'times' and count >= self.repeat_times:
                self.running = False
                break
            pyautogui.click(button=self.button_type, clicks=2 if self.click_type == 'double' else 1)
            count += 1
            time.sleep(self.interval)

    def toggle_autoclicker(self):
        if self.running:
            self.running = False
        else:
            self.running = True
            threading.Thread(target=self.click_mouse).start()


class AutoKey:
    def __init__(self):
        self.settings_file = AUTOKEY_SETTINGS_FILE
        self.settings = self.load_settings()
        self.interval = self.settings.get('interval', 0.1)
        self.key = self.settings.get('key', 'a')
        self.toggle_key = self.settings.get('toggle_key', 'f6')
        self.repeat_mode = self.settings.get('repeat_mode', 'until_stopped')
        self.repeat_times = self.settings.get('repeat_times', 1)
        self.running = False

        self.old_toggle_key = self.toggle_key

        self.setup_gui()

    def load_settings(self):
        if not os.path.exists(SETTINGS_DIR):
            os.makedirs(SETTINGS_DIR)
        if os.path.exists(self.settings_file):
            with open(self.settings_file, 'r') as f:
                return json.load(f)
        else:
            return {}

    def save_settings(self):
        with open(self.settings_file, 'w') as f:
            json.dump({
                'interval': self.interval,
                'key': self.key,
                'toggle_key': self.toggle_key,
                'repeat_mode': self.repeat_mode,
                'repeat_times': self.repeat_times
            }, f)

    def setup_gui(self):
        msg = "AutoKey Settings"
        title = "AutoKey"
        fieldNames = ["Millennium", "Century", "Year", "Month", "Week", "Day", "Hour", "Minute", "Second", "Millisecond",
                      "Key", "Toggle Key", "Repeat Mode (until_stopped/times)", "Repeat Times"]
        defaults = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    self.key, self.toggle_key, self.repeat_mode, self.repeat_times]
        while True:
            fieldValues = easygui.multenterbox(msg, title, fieldNames, defaults)
            if fieldValues:
                try:
                    time_params = {
                        'millisecond': int(fieldValues[9]),
                        'second': int(fieldValues[8]),
                        'minute': int(fieldValues[7]),
                        'hour': int(fieldValues[6]),
                        'day': int(fieldValues[5]),
                        'week': int(fieldValues[4]),
                        'month': int(fieldValues[3]),
                        'year': int(fieldValues[2]),
                        'century': int(fieldValues[1]),
                        'millennium': int(fieldValues[0])
                    }
                    self.interval = sum(value * multiplier for key, multiplier in {
                        'millennium': 1000 * 60 * 60 * 24 * 365 * 1000,
                        'century': 1000 * 60 * 60 * 24 * 365 * 100,
                        'year': 1000 * 60 * 60 * 24 * 365,
                        'month': 1000 * 60 * 60 * 24 * 30,
                        'week': 1000 * 60 * 60 * 24 * 7,
                        'day': 1000 * 60 * 60 * 24,
                        'hour': 1000 * 60 * 60,
                        'minute': 1000 * 60,
                        'second': 1000,
                        'millisecond': 1
                    }.items() if key in time_params for value in [time_params[key]]) / 1000
                except ValueError:
                    continue

                self.key = fieldValues[10].lower()
                self.toggle_key = fieldValues[11].lower()

                if fieldValues[12].lower() in ['until_stopped', 'times']:
                    self.repeat_mode = fieldValues[12].lower()
                else:
                    continue

                try:
                    self.repeat_times = int(fieldValues[13])
                except ValueError:
                    continue

                self.update_hotkey()
                self.save_settings()
                break
            else:
                sys.exit()

        self.show_controls()

    def update_hotkey(self):
        if self.old_toggle_key != self.toggle_key:
            keyboard.remove_hotkey(self.old_toggle_key)
            self.old_toggle_key = self.toggle_key
        keyboard.add_hotkey(self.toggle_key, self.toggle_autokey)

    def show_controls(self):
        msg = "AutoKey is running.\n\n" \
              "Press the toggle key to start/stop key action.\n" \
              "Press the Settings button to update settings.\n" \
              "Press the exit button to close the application."
        title = "AutoKey Running"
        choices = ["Settings", "Exit"]
        choice = easygui.buttonbox(msg, title, choices)

        if choice == "Settings":
            self.setup_gui()
        elif choice == "Exit":
            sys.exit()

    def perform_key_action(self):
        count = 0
        while self.running:
            if self.repeat_mode == 'times' and count >= self.repeat_times:
                self.running = False
                break
            keyboard.press_and_release(self.key)
            count += 1
            time.sleep(self.interval)

    def toggle_autokey(self):
        if self.running:
            self.running = False
        else:
            self.running = True
            threading.Thread(target=self.perform_key_action).start()


if __name__ == "__main__":
    tool_type = easygui.choicebox("Choose a tool to use:", "AutoPress Selection", ["AutoClick", "AutoKey"])
    if tool_type == "AutoClick":
        AutoClick()
    elif tool_type == "AutoKey":
        AutoKey()
    else:
        easygui.msgbox("No tool selected. Exiting.", title="Error")
        sys.exit()
